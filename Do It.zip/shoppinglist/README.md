# shoppinglist


[![CircleCI](https://circleci.com/gh/nobubelempande/shoppinglist/tree/main.svg?style=svg)](https://circleci.com/gh/nobubelempande/shoppinglist/tree/main)

[![codecov](https://codecov.io/gh/nobubelempande/shoppinglist/branch/main/graph/badge.svg?token=0JWJ1CBF6C)](https://codecov.io/gh/nobubelempande/shoppinglist)


This is a group project for the Software design course. We were tasked with developing an android application that will serve as a shopping list with functionalities such as creation of a new list, population of items in that list, viewing the total spending of each category and sharing the list with friends and family. The technologies we have checked are Figma for UI design, Android Studio for the front-end and SQLite as our back-end. We have also incoporated Jacoco for measuring code coverage in our code base and submitting reports to Codecov.
