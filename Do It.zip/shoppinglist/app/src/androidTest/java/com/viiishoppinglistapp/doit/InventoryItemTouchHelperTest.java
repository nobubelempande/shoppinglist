package com.viiishoppinglistapp.doit;

import junit.framework.TestCase;

import org.junit.Assert;

import androidx.appcompat.app.AlertDialog;

public class InventoryItemTouchHelperTest extends TestCase {

    public void testOnMove() {

    }

    public void testOnChildDraw() {


    }

    public void testOnSwiped() {

     //IDEA
    //Get Adapter Items number
    //assertEquals(testOnSwiped(AdapterItemsNumber-1);

    }

    public void testOnInventoryItemSwiped() {

    /*    InventoryItemTouchHelper Swiped = new InventoryItemTouchHelper();
        AlertDialog.Builder x = new AlertDialog.Builder(adapter.getContext());
        if (adapter.deleteItem(position)){
            AlertDialog.Builder y = new AlertDialog.Builder(adapter.getContext());
        }
        //assertNotSame(x&y);  */
    }
}